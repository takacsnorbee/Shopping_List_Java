/*REGISTRATION*/

var regButton = document.getElementById("regButton");
var regx = /^[A-Za-z0-9]{3,10}$/;
var validation = false;
var passWordValidation = false;

function validator(){
	var userName = document.getElementById("username").value;
	var passWord = document.getElementById("password").value;
	var passWord2 = document.getElementById("password2").value;
	var warning = document.getElementById("warning");
	
	if (regx.test(userName) && regx.test(passWord)) {
		validation = true;
	} 
	if (passWord == passWord2){
		passWordValidation = true;
	}
}

regButton.addEventListener("click", function(){
	validator();
	if (!validation) {
		alert('Invalid username or password! Username and password must be 3-10 character. Only number or letter allowed!');
		document.getElementById("regex").value="wrong";
	} 
	if (!passWordValidation) {
		alert('The passwords do not match. Try it again.');
		document.getElementById("regex").value="wrong";
	} 
	
})