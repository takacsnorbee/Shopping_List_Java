/*DATE*/

date = () => {
  var date = new Date();
  document.getElementById("date").innerHTML = date.getFullYear();
}
date();