/*ADD*/

var buttonAdd = document.getElementById("addItem");
var buttonSave = document.getElementById("saveListButton");

var input = document.getElementById("inputText")
var listName = document.getElementById("inputListName");
var saveListName = document.getElementById("saveListInputName");
var saveList = document.getElementById("saveListInput");

var ul = document.querySelector("ul");
var li = document.getElementsByTagName("li");

function creatListElement(){
	var li = document.createElement("li");
		li.appendChild(document.createTextNode(input.value));
		ul.appendChild(li);
		input.value="";
}

buttonAdd.addEventListener("click", function(){
	if (input.value.length >= 3) {
		creatListElement();
	}
});

input.addEventListener("keypress", function(event){
	if (input.value.length >= 3 && event.keyCode === 13) {
		creatListElement();
	}
});

buttonSave.addEventListener("click", function(){
	console.log(listName.value);
	if (listName.value != "" && li.length > 0) {
		saveListName.value = listName.value;
		for(var i = 0; i < li.length; i++) {
			saveList.value += li[i].innerHTML + ";";
			console.log(saveList.value);
		}
	} 
})

/*DELETE*/

var buttonDel = document.getElementById("deleteItem");

buttonDel.addEventListener("click", function(){
	ul.removeChild(ul.childNodes[ul.childNodes.length-1]);
});