/*MODIFY*/

var whereTo = document.getElementById("addNewBtn");
var div = document.getElementById("addNew");

whereTo.addEventListener("click", function(){
	var newInput = document.createElement("input");
	var attName = document.createAttribute("name");
	var attText = document.createAttribute("type");
	attName.value = "listInput";
	attText.value = "text";
	newInput.setAttributeNode(attName);
	newInput.setAttributeNode(attText);
	div.insertBefore(newInput, whereTo);
});