package home.projekt.shoppingList.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import home.projekt.shoppingList.entity.UsersList;
import home.projekt.shoppingList.repository.UsersListRepository;

@Service
public class UserListService {

	@Autowired
	private UsersListRepository ulr;

	public UsersList findListById(Integer id) {
		return ulr.getOne(id);
	}
	
	public void deleteList(UsersList userList) {
		ulr.delete(userList);
	}
	
	public void saveList(UsersList userLists) {
		ulr.save(userLists);
	}
}
