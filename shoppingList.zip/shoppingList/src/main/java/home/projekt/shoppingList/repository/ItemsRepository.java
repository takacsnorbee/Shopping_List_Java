package home.projekt.shoppingList.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import home.projekt.shoppingList.entity.Items;

@Repository
public interface ItemsRepository extends JpaRepository<Items, Integer>{
	
}
