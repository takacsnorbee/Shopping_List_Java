package home.projekt.shoppingList.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import home.projekt.shoppingList.entity.Items;
import home.projekt.shoppingList.entity.User;
import home.projekt.shoppingList.entity.UsersList;
import home.projekt.shoppingList.service.RegistrationService;

@Controller
@SessionAttributes("user")
public class NewListController {
	
	@Autowired
	private RegistrationService rs;

	@RequestMapping(value = "newlist", method = RequestMethod.GET)
	public String newListView(ModelMap model) {
		
		if (model.getAttribute("user") == null) {
			return "redirect:/login";
		} else {
			User user = (User)model.getAttribute("user");
			model.put("username", user.getUsername());
			model.put("userId", user.getId());
			return "sl_newList";
		}
	}
	
	@RequestMapping(value = "addnewlist", method = RequestMethod.POST)
	public String addNewList(Integer id, String nameOfList, String list) {
	
		String[] items = list.split(";");
		
		User user = rs.findUserById(id);			
		UsersList newList = new UsersList();		
		
		newList.setNameOfList(nameOfList);
		newList.setUser(user);
		user.getUsersList().add(newList);
		
		for (int i = 0; i < items.length; i++) {
			Items newItem = new Items();
			newItem.setItem(items[i]);
			newItem.setUsersList(newList);
			newList.getItems().add(newItem);
		}
		rs.saveUser(user);
		return "redirect:/newlist";
	}
}
