package home.projekt.shoppingList.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import home.projekt.shoppingList.entity.User;
import home.projekt.shoppingList.repository.UserRepository;

@Service
public class RegistrationService {

	@Autowired
	private UserRepository ur;
	
	public void saveUser(User user) {
		ur.save(user);
	}
	
	public User findUser(User user) {
		return ur.findByUsername(user.getUsername());
	}
	
	public User findUserById(Integer id) {
		return ur.getOne(id);
	}
}
