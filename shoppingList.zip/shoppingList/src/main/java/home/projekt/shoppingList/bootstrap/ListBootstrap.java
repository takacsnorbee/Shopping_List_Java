package home.projekt.shoppingList.bootstrap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import home.projekt.shoppingList.entity.Items;
import home.projekt.shoppingList.entity.User;
import home.projekt.shoppingList.entity.UsersList;
import home.projekt.shoppingList.repository.UserRepository;

@Component
public class ListBootstrap implements ApplicationListener<ContextRefreshedEvent> {
	
	@Autowired
	private UserRepository ur;
	
	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		
		User baseUser = new User();
		baseUser.setUsername("adolf");
		baseUser.setPassword("123");
		baseUser.setEmail("email@email.hu");
		
		UsersList baseUserList = new UsersList();
		baseUserList.setNameOfList("baseList");
		baseUserList.setUser(baseUser);
		
		Items baseUserListItemsOne = new Items();
		baseUserListItemsOne.setItem("vodka");
		baseUserListItemsOne.setUsersList(baseUserList);
		
		Items baseUserListItemsTwo = new Items();
		baseUserListItemsTwo.setItem("beer");
		baseUserListItemsTwo.setUsersList(baseUserList);
		
		baseUserList.getItems().add(baseUserListItemsOne);
		baseUserList.getItems().add(baseUserListItemsTwo);
		
		baseUser.getUsersList().add(baseUserList);
		
		ur.save(baseUser);
	}

}





