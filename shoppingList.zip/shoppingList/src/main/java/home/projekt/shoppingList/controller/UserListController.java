package home.projekt.shoppingList.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import home.projekt.shoppingList.entity.Items;
import home.projekt.shoppingList.entity.User;
import home.projekt.shoppingList.entity.UsersList;
import home.projekt.shoppingList.service.RegistrationService;
import home.projekt.shoppingList.service.UserListService;

@Controller
@SessionAttributes({"user","delThis"})
public class UserListController {
	
	@Autowired
	private UserListService uls;
	
	@Autowired
	private RegistrationService rs;
	
	@RequestMapping(value = "userlist", method = RequestMethod.GET)
	public String userListView(ModelMap model, @RequestParam Integer id) {
		
		if (model.getAttribute("user") == null) {
			return "redirect:/login";
		} else {
			User user = (User)model.getAttribute("user");
			User userRefresh = rs.findUserById(user.getId());
			List<UsersList> usersList = userRefresh.getUsersList();
			model.put("userList", usersList);
			model.put("username", user.getUsername());
			
			if (id != 0) {
				UsersList lists = uls.findListById(id);
				List<Items> listItems = lists.getItems();
				model.put("listItems", listItems);
			}
			
			return "sl_lists";
		}	
	}
	@RequestMapping(value = "modifyList", method = RequestMethod.POST)
	public String showList(ModelMap model, String[] listInput, String deleteWasHit) {
		
		UsersList updateThisList = uls.findListById((Integer)model.getAttribute("delThis"));
		String nameOfList = updateThisList.getNameOfList();
		Integer userId = updateThisList.getUser().getId();
		
		//DELETE
		uls.deleteList(updateThisList);
		
		//MAKE NEW LIST
		User user = rs.findUserById(userId);			
		UsersList newList = new UsersList();		
			
		newList.setNameOfList(nameOfList);
		newList.setUser(user);
		user.getUsersList().add(newList);
			
		for (int i = listInput.length - 1; i >= 0; i--) {
			if (!listInput[i].replaceAll(" ", "").equals("")) {
				Items newItem = new Items();
				newItem.setItem(listInput[i]);
				newItem.setUsersList(newList);
				newList.getItems().add(newItem);
			} 
		}
		rs.saveUser(user);
		
		return "redirect:/userlist?id=" + 0;
	}
	
	@RequestMapping(value = "deleteList", method = RequestMethod.POST)
	public String deleteUserList(ModelMap model) {
		UsersList delThisList = uls.findListById((Integer)model.getAttribute("delThis"));
		uls.deleteList(delThisList);
		return "redirect:/userlist?id=" + 0;
	}
	
	@RequestMapping(value = "chooseList", method = RequestMethod.POST)
	public String chooseUserList(Integer choosenId, Model model) {
		model.addAttribute("delThis", choosenId);
		return "redirect:/userlist?id=" + choosenId;
	}
}
