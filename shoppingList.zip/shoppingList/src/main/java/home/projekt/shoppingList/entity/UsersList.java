package home.projekt.shoppingList.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class UsersList {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String nameOfList;
	@ManyToOne
	private User user;
	@OneToMany(mappedBy = "usersList", cascade = CascadeType.ALL)
	private List<Items> items = new ArrayList<>();
	
	public List<Items> getItems() {
		return items;
	}
	public void setItems(List<Items> items) {
		this.items = items;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Integer getId() {
		return id;
	}
	public String getNameOfList() {
		return nameOfList;
	}
	public void setNameOfList(String nameOfList) {
		this.nameOfList = nameOfList;
	}
	public void setId(Integer id) {
		this.id = id;
	}
}
