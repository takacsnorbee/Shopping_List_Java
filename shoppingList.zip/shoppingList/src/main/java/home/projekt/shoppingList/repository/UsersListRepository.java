package home.projekt.shoppingList.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import home.projekt.shoppingList.entity.UsersList;

@Repository
public interface UsersListRepository extends JpaRepository<UsersList, Integer>{

}
