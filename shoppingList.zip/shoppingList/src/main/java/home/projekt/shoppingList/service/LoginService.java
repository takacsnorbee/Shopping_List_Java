package home.projekt.shoppingList.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import home.projekt.shoppingList.entity.User;
import home.projekt.shoppingList.repository.UserRepository;

@Service
public class LoginService {

	@Autowired
	private UserRepository ur;
	
	public User findUser(User user) {
		return ur.findByUsernameAndPassword(user.getUsername(), user.getPassword());
	}
}
