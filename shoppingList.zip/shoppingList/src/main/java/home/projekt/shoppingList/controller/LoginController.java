package home.projekt.shoppingList.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import home.projekt.shoppingList.entity.User;
import home.projekt.shoppingList.service.LoginService;

@Controller
@SessionAttributes("user")	
public class LoginController {
	
	@Autowired
	private LoginService ls;

	@RequestMapping(value = {"login", "/"}, method = RequestMethod.GET)
	public String loginView(SessionStatus sessionStatus) {
		sessionStatus.setComplete();
		return "sl_login";
	}
	
	@RequestMapping(value = "loginPost", method = RequestMethod.POST)
	public String login(User user, ModelMap model) {
		User actualUser = ls.findUser(user);
		
		if (actualUser == null) {
			model.addAttribute("wrongLogin", "Wrong username or password");
			return "sl_login";
		} else {
			model.put("user", actualUser);
			return "redirect:/userlist?id=0";
		}
	}
}
