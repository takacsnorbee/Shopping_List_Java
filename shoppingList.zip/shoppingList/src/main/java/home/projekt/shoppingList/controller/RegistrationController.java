package home.projekt.shoppingList.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import home.projekt.shoppingList.entity.User;
import home.projekt.shoppingList.service.RegistrationService;

@Controller
public class RegistrationController {
	
	@Autowired
	private RegistrationService rs;

	@RequestMapping(value = "registration", method = RequestMethod.GET)
	public String registrationView() {
		return "sl_registration";
	}
	
	@RequestMapping(value = "registrationPost", method = RequestMethod.POST)
	public String login(User user, String regex, Model model) {
		
		if (!regex.equals("wrong")) {
			if (rs.findUser(user) == null) {
				rs.saveUser(user);
				return "redirect:/login";
			} else {
				model.addAttribute("wrongRegistration", "Username already used");
				return "sl_registration";
			}
		} else {
			return "redirect:/registration";
		}
	}
}
